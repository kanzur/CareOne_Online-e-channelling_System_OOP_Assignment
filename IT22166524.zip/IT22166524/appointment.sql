SELECT * FROM careone.appointment;

INSERT INTO appointment (AID,Name,Email,Phone,Message,RID,Date,Department)
VALUES ('2', 'Kamal', 'kamal@gmail.com', '0118826541','Hi world','2','2004-11-4','Food');
INSERT INTO appointment (AID,Name,Email,Phone,Message,RID,Date,Department)
VALUES ('6', 'vimal', 'vimal@gmail.com', '0127896311','Hello','6','2003-10-3','School');
INSERT INTO appointment (AID,Name,Email,Phone,Message,RID,Date,Department)
VALUES ('4', 'nimal', 'nimal@gmail.com', '0717856542','goat','4','2018-2-3','Transport');
INSERT INTO appointment (AID,Name,Email,Phone,Message,RID,Date,Department)
VALUES ('5', 'sunil', 'sunil@gmail.com', '0723654981','toad','5','1990-1-10','Public');
INSERT INTO appointment (AID, Name, Email, Phone, Message, RID, Date, Department) 
VALUES ('7', 'Kisal', 'kisal@gmail.com', '0117892341', 'Hello kisal', '7', '2006-08-25', 'General');
INSERT INTO appointment (AID, Name, Email, Phone, Message, RID, Date, Department) 
VALUES ('8', 'rusiru', 'rusiru@gmail.com', '0117896760', 'Hello chan', '8', '2012-03-18', 'Health');
INSERT INTO appointment (AID, Name, Email, Phone, Message, RID, Date, Department) 
VALUES ('9', 'rihan', 'rihan@gmail.com', '0128996541', 'Hello rizzik', '9', '2023-08-25', 'Cardiology');
INSERT INTO appointment (AID, Name, Email, Phone, Message, RID, Date, Department) 
VALUES ('10', 'shehan', 'shehan@gmail.com', '0117858360', 'Hello henin', '10', '2002-12-31', 'Health');
INSERT INTO appointment (AID, Name, Email, Phone, Message, RID, Date, Department) 
VALUES ('11', 'rizwan', 'rizwan@gmail.com', '0125116541', 'Hello rizwan23', '11', '2001-05-02', 'Cardiology');
INSERT INTO appointment (AID, Name, Email, Phone, Message, RID, Date, Department) 
VALUES ('12', 'shafique', 'shafique@gmail.com', '0125222541', 'please help me', '12', '2018-09-018', 'General');
