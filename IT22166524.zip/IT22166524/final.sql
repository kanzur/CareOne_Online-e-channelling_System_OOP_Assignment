-- Create the Careone database
CREATE DATABASE Careone;

-- Use the Careone database
USE Careone;

-- Create the Registered_User table
CREATE TABLE Registered_User (
    RID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(30),
    Phone VARCHAR(20), 
    Username VARCHAR(20),
    Password VARCHAR(20)  
);

-- Create the appointment table
CREATE TABLE appointment (
    AID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(30),
    Email VARCHAR(40),
    Phone VARCHAR(20),  -- Changed data type to VARCHAR
    Message TEXT,
    RID INT,
    CONSTRAINT FK_Registered_User FOREIGN KEY (RID) REFERENCES Registered_User(RID)
);

-- Create the contactus table
CREATE TABLE contactus (
    CID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(30),
    Email VARCHAR(40),
    Message TEXT,
    RID INT,
    CONSTRAINT FK_Registered_User_ContactUs FOREIGN KEY (RID) REFERENCES Registered_User(RID)
);

-- Create the Registered_Doctor table
CREATE TABLE Registered_Doctor (
    DID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(30),
    Phone VARCHAR(20),  -- Changed data type to VARCHAR
    Username VARCHAR(20),
    Password VARCHAR(20)  -- Changed data type to VARCHAR
);

-- Create the support table
CREATE TABLE support (
    SID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(30),
    Email VARCHAR(40),
    Message TEXT,
    DID INT,
    CONSTRAINT FK_Registered_Doctor_Support FOREIGN KEY (DID) REFERENCES Registered_Doctor(DID)
);

-- Select all records from the support table
SELECT * FROM Registered_User;

Desc Registered_User;

INSERT INTO Registered_User (Name, Phone, Username, Password)
VALUES ('John Doe', '123-456-7890', 'johndoe123', 'password123');

select * from Registered_User where Username='kamil12';

SELECT * FROM Registered_Doctor;

INSERT INTO Registered_Doctor (Name, Phone, Username, Password)
VALUES ('John', '0178965432', 'john456', 'jo1234');

SELECT * FROM careone.support;
Select * from careone.contactus;

INSERT INTO contactus (CID,Name,Email,Message,RID,Subject)
VALUES ('1','Kamal','kamal@gmail.com','cheese is tasty','1','fever');
INSERT INTO contactus (CID,Name,Email,Message,RID,Subject)
VALUES ('2','NImal','nimal@gmail.com','Im sick','2','cough');
INSERT INTO contactus (CID,Name,Email,Message,RID,Subject)
VALUES ('3','Sunil','sunil@gmail.com','Im sleeping','3','headache');
INSERT INTO contactus (CID,Name,Email,Message,RID,Subject)
VALUES ('4','Ramal','ramal@gmail.com','eyes are paining','4','eye pain');

 INSERT INTO support (SID,Name,Email,Message,DID,Subject)
VALUES ('1','Kamalan','kamalan@gmail.com','hi','1','call');
 INSERT INTO support (SID,Name,Email,Message,DID,Subject)
VALUES ('2','Nimalan','nimalan@gmail.com','hee','2','attend');
 INSERT INTO support (SID,Name,Email,Message,DID,Subject)
VALUES ('3','saman','saman@gmail.com','good morning','3','Cannot access website');
 INSERT INTO support (SID,Name,Email,Message,DID,Subject)
VALUES ('4','kiwan','kiwan@gmail.com','im exhausted','4','Doctor is not availbale im in an emergency');
INSERT INTO support (SID,Name,Email,Message,DID,Subject)
VALUES ('5','eric','eric@gmail.com','i cannot do anymore','5','Technical error');
INSERT INTO support (SID,Name,Email,Message,DID,Subject)
VALUES ('6','janu','janu@gmail.com','Im dead bcz of the project','6','Mental error');



SELECT * FROM Registered_User;
SELECT * FROM Registered_Doctor;
SELECT * FROM appointment;
SELECT * FROM contactus;
SELECT * FROM support;
